#!/usr/bin/env ruby

n = 1
factor = 2

[1,2,3,4,5].each do |n|
  puts "#{n} x #{factor} = #{n*factor}"
end

puts n
