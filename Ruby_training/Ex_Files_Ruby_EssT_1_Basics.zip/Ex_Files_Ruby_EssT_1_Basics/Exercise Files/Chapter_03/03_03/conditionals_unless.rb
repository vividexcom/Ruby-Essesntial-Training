cart = ['apple', 'banana', 'carrot']

unless cart.empty?
  puts "The first item is: #{cart[0]}"
else
  puts "The cart is empty."
end
