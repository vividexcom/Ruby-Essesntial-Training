#!/usr/bin/env ruby

print "What is your name? "
response = gets.chomp

puts "Hello, #{response}!"
