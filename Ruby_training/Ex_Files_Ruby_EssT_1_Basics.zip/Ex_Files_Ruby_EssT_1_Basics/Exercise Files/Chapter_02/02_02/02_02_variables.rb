# This file is a transcript of the IRB session shown in the movie.
# You should be able to cut and paste it into IRB to get 
# the same results shown in the comments.

# irb
x = 1
# => 1
x
# => 1
x + 1
# => 2
y
# NameError: undefined local variable or method 'y'
y = 2
# => 2
y
# => 2
z = x + y
# => 3
puts z
# 3
# => nil
aw_counter = 100
# => 100
articles_written = 100
quit
