# This file is a transcript of the IRB session shown in the movie.
# You should be able to cut and paste it into IRB to get 
# the same results shown in the comments.

# irb
nil.class
# => NilClass
nil == false
# => false
nil.nil?
# => true
x = nil
# => nil
x.nil?
# => true
x == nil
# => true
!x
# => true
quit
