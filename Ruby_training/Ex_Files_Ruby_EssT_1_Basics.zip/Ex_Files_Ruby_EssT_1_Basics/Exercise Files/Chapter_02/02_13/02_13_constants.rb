# This file is a transcript of the IRB session shown in the movie.
# You should be able to cut and paste it into IRB to get 
# the same results shown in the comments.

# irb
MAX_SCORE = 100
# => 100
max_score = 100
# => 100
MAX_SCORE == max_score
# => false
MAX_SCORE = 50
# warning: already initialized constant
# => 50
MAX_SCORE
# => 50
Temp = 72
# => 72
Temp = 68
# warning: already initialized constant
# => 68
quit
